#include<iostream>
#include <windows.h>
#include<cstring>
using namespace std;
string defcolor = "\033[93m";
string outcolor = "\033[96m";
string message = "\033[95m";
string error = "\033[91m";
string ok = "\033[92m";