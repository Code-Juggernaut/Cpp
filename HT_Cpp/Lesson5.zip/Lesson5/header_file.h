#include<iostream>
#include<cstring>
#include<stdlib.h>
using namespace std;
string defcolor = "\033[93m";
string outcolor = "\033[96m";
string message = "\033[95m";
string error = "\033[91m";
string ok = "\033[92m";

const short sizex = 5;
const short sizey = 5;