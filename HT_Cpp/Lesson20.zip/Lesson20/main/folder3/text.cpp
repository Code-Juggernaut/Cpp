files in folder3
