#include "header_file.h"
int main(){
    int number = 0;
    cout<<defcolor<<"---TASK 6---\n";
    cout<<"enter number";
    cin>>number;
    cout<<"number % i = 0 if i = "<<message;
    for(int i = 1;i<=abs(number);i++){
        if(number%i == 0){
            cout<<i<<" ";
            cout<<-i<<" ";
        }
    }
}