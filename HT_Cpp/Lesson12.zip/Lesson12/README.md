## str_functions.h
>[!WARNING] You need to link this library to run my code

---Compiled with MinGW64---
`g++ task1.c libs/dynamic_arr.c` will work
`g++ task1.c` **will not work** — missing `libs/dynamic_arr.c`