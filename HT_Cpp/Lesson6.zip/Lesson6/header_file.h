#include<iostream>

#define ok "\033[92m"
#define error "\033[91m"
#define basic "\033[93m"
#define input "\033[94m"
#define message "\033[95m"
#define out "\033[96m"
#define end '\n'
using namespace std;